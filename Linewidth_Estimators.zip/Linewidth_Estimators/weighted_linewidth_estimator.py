# This is a linewidth estimator
# by Tyrone Thames
#
# To run this script:
#   In Poky Notepad,
#     File -> Run Python Module
import numpy as np
import csv
import __main__
s = __main__.main_session
proj = s.project

print('\n\n\n------------------------------------------------------')
print('FWHM Linewidth Estimator')
print('by Tyrone Thames')
print('Department of Physics, University of Central Florida')
print('------------------------------------------------------')

directory = "C:/Users/Kenzie/Documents/Research/HTLV_CA/HTLV_ARTIST/Peak List Processing/python scripts/make_rows_in_3dncacx_peaklist/"

# Function to estimate FWHM from a point off-center
def estimate_fwhm_from_point(cen, height, x_point, y_point):
    # For a Gaussian, FWHM = 2 * sqrt(2 * ln(2)) * sigma
    estimated_sigma = np.abs(x_point - cen) / np.sqrt(-2 * np.log(y_point/height))
    fwhm = 2.35482 * estimated_sigma
    return fwhm

# Function to calculate weighted FWHM
def estimate_weighted_fwhm(points):
    cen, height = points[0][0], points[0][1]
    maxheight = max([p[1] for p in points])
    if height<=0: height=1
    if height<maxheight:
        print(points)
        #print("height:", height, ", maxheight:", maxheight)
    
    fwhm_weighted_sum = 0
    weight_sum = 0
    fwhms = []
    for point in points[1:]:
        x_point, y_point = point
        weight = 1 / np.abs(x_point - cen)#WEIGHT FUNCTION
        fwhm = estimate_fwhm_from_point(cen, height, x_point, y_point)
        
        fwhm_weighted_sum += fwhm * weight
        weight_sum += weight
        fwhms.append(fwhm)
    
    fwhm_weighted = fwhm_weighted_sum / weight_sum
    
    return fwhm_weighted#, fwhms

#Run the linewidth estimator for every peak in the peaklist
for spec in proj.spectrum_list():
    thelist=[]#new peaklist for peaks with their linewidths
    # Show peak information
    for peak in spec.peak_list():
        maxm = peak.data_height#gaussian center height
        loc = list(peak.position)#peak center location
        linewidth = [[0.0,0.0] for l in loc]
        for w in range(len(loc)):#number of coordinate values
            points=[[loc[w], maxm]]
            for d in [-1,1]:#both directions
                for i in range(1,6):
                    loc = list(peak.position)
                    loc[w]+=d*i*0.1
                    points.append([loc[w], spec.data_height(tuple(loc))])
            linewidth[w]=estimate_weighted_fwhm(points)
        thelist.append([*loc, *linewidth, maxm])
        print(thelist[-1])
    #Write peaklist
    with open(directory+spec.name+"_peaklist.csv", 'w', newline='') as file:
        writer = csv.writer(file)
        for line in thelist:
            writer.writerow(line)
# # Example usage
# points = [(0, 1), (-1, 0.6), (1, 0.6), (-2, 0.2), (2, 0.2)]
# fwhm_weighted = estimate_weighted_fwhm(points)
# print(f"Weighted FWHM: {fwhm_weighted}")
