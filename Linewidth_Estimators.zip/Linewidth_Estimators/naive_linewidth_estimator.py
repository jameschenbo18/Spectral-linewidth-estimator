# This is a linewidth estimator
# by Tyrone Thames
# 
# To run this script:
#   In Poky Notepad,
#     File -> Run Python Module
import csv
import __main__
s = __main__.main_session
proj = s.project

print('\n\n\n------------------------------------------------------')
print('Linewidth Estimator')
print('by Tyrone Thames')
print('Department of Physics, University of Central Florida')
print('------------------------------------------------------')

directory = "C:/Users/Kenzie/Documents/Research/HTLV_CA/HTLV_ARTIST/Peak List Processing/python scripts/make_rows_in_3dncacx_peaklist/"
# Show spectrum information
# print('\n* Spectrum Information')
for spec in proj.spectrum_list():
    thelist=[]
    # Show peak information
    for peak in spec.peak_list():
        maxm = peak.data_height
        loc = list(peak.position)
        linewidth = [[0.0,0.0] for l in loc]
        for w in range(len(loc)):#number of coordinate values
            for d in [-1,1]:#both directions
                loc = list(peak.position)
                for i in range(100):
                    loc[w]+=d*0.01
                    if spec.data_height(tuple(loc))<=maxm/2:
                        linewidth[w][int(bool(d+1))]=i/100
                        break
        thelist.append([*loc, *linewidth, maxm])
        print(thelist[-1])
    
        #data_height((2.87, 4.334)) = 321833.23
      #  print((peak.assignment, peak.frequency, peak.data_height))
    with open(directory+spec.name+"_peaklist.csv", 'w', newline='') as file:
        writer = csv.writer(file)
        for line in thelist:
            writer.writerow(line)
    #Peak:
    #   position = (4.35, 5.12)		# in ppm
    #	data_height = 104334.23		# closest NMR data value
